<?php
/**
3ème version :  afficher la liste des livres d'un auteur dont le nom est passé dans l'URL.
Exemple : pour obtenir les livres écrits par Alan Moore, il faut utiliser l'URL :
recherche_3.php?type=auteur&quoi=Moore
*/

ob_start('ob_gzhandler'); //démarre la bufferisation, compression du tampon si le client supporte gzip

require_once '../php/bibli_generale.php';
require_once '../php/bibli_bookshop.php';

error_reporting(E_ALL); // toutes les erreurs sont capturées (utile lors de la phase de développement)

$pageToRedirect = '../index.php';

/* Contrôle de la validité des informations reçues */
(count($_GET) != 2 || ! isset($_GET['type']) || ! isset($_GET['quoi'])) && fd_redirige($pageToRedirect);
($_GET['type'] != 'auteur') && fd_redirige($pageToRedirect);

$quoi = trim($_GET['quoi']);
$notags = strip_tags($quoi);
(mb_strlen($notags, 'UTF-8') != mb_strlen($quoi, 'UTF-8')) && fd_redirige($pageToRedirect);


fd_html_debut('BookShop | Recherche', '../styles/bookshop.css');

fd_bookshop_enseigne_entete(true,'../');

fdl_contenu($quoi);

fd_bookshop_pied();

fd_html_fin();

ob_end_flush();


// ----------  Fonctions locales au script ----------- //

/**
 *	Contenu de la page : résultats de la recherche
 *
 * @param string $quoi nom de l'auteur recherché
 */
function fdl_contenu($quoi) {
	// ouverture de la connexion, requête
	$bd = fd_bd_connect();
	
	$q = fd_bd_protect($bd, $quoi); 
	
	$sql = "SELECT liID, liTitre, liPrix, liPages, liISBN13, edNom, edWeb, auNom, auPrenom 
			FROM livres INNER JOIN editeurs ON liIDEditeur = edID 
						INNER JOIN aut_livre ON al_IDLivre = liID 
						INNER JOIN auteurs ON al_IDAuteur = auID 
			WHERE liID in (SELECT al_IDLivre FROM aut_livre INNER JOIN auteurs ON al_IDAuteur = auID WHERE auNom = '$q')";

	$res = mysqli_query($bd, $sql) or fd_bd_erreur($bd,$sql);
	
	echo '<h3>Livre(s) écrit(s) par l\'auteur de nom "', fd_protect_sortie($quoi), '"</h3>'; 
	
	$lastID = -1;
	while ($t = mysqli_fetch_assoc($res)) {
		if ($t['liID'] != $lastID) {
			if ($lastID != -1) {
				fdl_afficher_livre($livre);	
			}
			$lastID = $t['liID'];
			$livre = array(	'id' => $t['liID'], 
							'titre' => $t['liTitre'],
							'edNom' => $t['edNom'],
							'edWeb' => $t['edWeb'],
							//'resume' => $t['liResume'],
							'pages' => $t['liPages'],
							'ISBN13' => $t['liISBN13'],
							'prix' => $t['liPrix'],
							'auteurs' => array(array('prenom' => $t['auPrenom'], 'nom' => $t['auNom']))
						);
		}
		else {
			$livre['auteurs'][] = array('prenom' => $t['auPrenom'], 'nom' => $t['auNom']);
		}		
	}
    // libération des ressources
	mysqli_free_result($res);
	mysqli_close($bd);
    
	if ($lastID != -1) {
		fdl_afficher_livre($livre);	
	}
	else{
		echo '<p>Aucun livre trouvé</p>';
	}
	

		
}	
	
/**
 *	Affichage d'un livre.
 *
 *	@param	array		$livre 		tableau associatif des infos sur un livre (id, auteurs(nom, prenom), titre, prix, pages, ISBN13, edWeb, edNom)
 *
 */
function fdl_afficher_livre($livre) {
	echo 
		'<div class="bcResultat">', 
			// TODO : à modifier pour le projet  
			'<a class="addToCart" href="#" title="Ajouter au panier"></a>',
			'<a class="addToWishlist" href="#" title="Ajouter à la liste de cadeaux"></a>',
			'<a href="details.php?article=', $livre['id'], '" title="Voir détails"><img src="../images/livres/', $livre['id'], '_mini.jpg" alt="', 
			fd_protect_sortie($livre['titre']),'"></a>',
            '<strong>', fd_protect_sortie($livre['titre']), '</strong> <br>',
			'Ecrit par : ';
	$i = 0;
	foreach ($livre['auteurs'] as $auteur) {
		if ($i > 0) {
			echo ', ';
		}
		$i++;
		echo '<a href="recherche_3.php?type=auteur&quoi=', urlencode($auteur['nom']), '">',fd_protect_sortie($auteur['prenom']), ' ', fd_protect_sortie($auteur['nom']) ,'</a>';
	}
			
    echo	'<br>Editeur : <a class="lienExterne" href="http://', fd_protect_sortie($livre['edWeb']), '" target="_blank">', fd_protect_sortie($livre['edNom']), '</a><br>',
            'Prix : ', $livre['prix'], ' &euro;<br>',
            'Pages : ', $livre['pages'], '<br>',
            'ISBN13 : ', fd_protect_sortie($livre['ISBN13']), '</div>';
}

?>
