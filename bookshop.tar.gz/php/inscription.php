<?php
	ob_start('ob_gzhandler'); //démarre la bufferisation, compression du tampon si le client supporte gzip

	require_once '../php/bibli_generale.php';
	require_once '../php/bibli_bookshop.php';

	fd_html_debut('BookShop | Recherche', '../styles/bookshop.css');

	fd_bookshop_enseigne_entete(true,'../');

	$err = array();
	$redirection = "http://localhost/bookshop/php/inscription.php";
	$ref = $_SERVER['HTTP_REFERER'];
	if($redirection != $ref){
		$redirection = $ref;
	}

	$valEmail;
	$valNom;
	$pass;
	$valJ;
	$valM;
	$valA;

	$valEmail=($_POST['email']?$_POST['email']:"");
	$valNom=($_POST['nomprenom']?$_POST['nomprenom']:"");
	$valJ=($_POST['naiss_j']?$_POST['naiss_j']:0);
	$valM=($_POST['naiss_m']?$_POST['naiss_m']:0);
	$valA=($_POST['naiss_a']?$_POST['naiss_a']:0);
	$pass=$_POST['pass1'];

	$bd = fd_bd_connect();
	$q1 = fd_bd_protect($bd, $valEmail); 
	$q2 = fd_bd_protect($bd, $valNom);
	$q3 = fd_bd_protect($bd, $_POST['pass1']);
	$q4 = fd_bd_protect($bd, $_POST['pass2']);

	$err[] = ms_traitement_email($err);
	$err[] = ms_traitement_nom($err);
	$err[] = ms_traitement_mdp($err);
	$err[] = ms_traitement_date($err);

	$sql = 	"INSERT INTO clients (cliEmail, cliPassword,cliNomPrenom,cliDateNaissance,cliAdresse,cliCP,cliVille,cliPays)
		VALUES ($valEmail, $pass, $valNom, $valJ/$valM/$valA, adresse, 00000, ville, pays)";

	if($err[0] != null || $err[1] != null || $err[2] != null || $err[3] != null){
		echo 
			'<div id="erreur">Attention, votre inscription n\'a pas pu être réalisée à cause des erreurs suivantes :',
			'<ul>';
		foreach($err as $Var){
			echo '<li>', $Var,'</li>';
		}
		echo '</ul></div>';
	}else{
		mysqli_query($bd, $sql);
	}

	


	echo
		'<h1> Inscription à Bookshop </h1>',
		'<p>',
		'<form action=inscription.php method=POST>',
		'<legend>Pour vous inscrire, merci de fournir les informations suivantes.</legend>',
		'<table>',
			ms_form_ligne("Votre adresse email : ", ms_form_input("text", "email", $valEmail, "exemple@email.com", 30)),
			ms_form_ligne("Choisissez un mot de passe : ", ms_form_input("password", "pass1", "", "Entre 4 et 20 caractères", 30)),
			ms_form_ligne("Répétez le mot de passe : ", ms_form_input("password", "pass2", "", "Entre 4 et 20 caractères", 30)),
			ms_form_ligne("Nom et prénom : ", ms_form_input("text", "nomprenom", $valNom, "Nom Prénom", 30)),
			ms_form_ligne("Date de naissance : ", ms_form_date("naiss", $valJ, $valM, $valA)),
			'<tr><td colspan=2 class="submit">', ms_form_input("submit", "envoyer", "'Je m inscris !'", "", 0), '</td></tr>',
		'</table>',
		 '</form>',
		 '</p>';


	fd_bookshop_pied();

	fd_html_fin();

	ob_end_flush();


	function ms_traitement_email($err){
		if(!(mb_strpos($_POST['email'], '@') < mb_strpos($_POST['email'], '.'))){
			return 'L\'adresse email ne respecte pas le bon format';
		}
	}

	function ms_traitement_nom($err){
		$nom = trim($_POST['nomprenom']);
		$long = mb_strlen($nom, 'UTF-8');
		if($long < 2 || $long > 100) {
			return 'Le nom et le prénom ne sont pas valides';
		}
	}

	function ms_traitement_mdp($err){
		if(strlen($_POST['pass1']) < 4 || strlen($_POST['pass1']) > 20) {
			return 'Le mot de passe n\'est pas valide';
		}
		if($_POST['pass1'] != $_POST['pass2']){
			return 'Les mots de passe doivent être identiques';
		}
	}

	function ms_traitement_date($err){
		if($_POST['naiss_j'] == 31){
			if($_POST['naiss_m'] == 2 || $_POST['naiss_m'] == 4 || $_POST['naiss_m'] == 6 || $_POST['naiss_m'] == 9 || $_POST['naiss_m'] == 11){
				return 'La date de naissance n\'est pas valide';
			}
		}
		if($_POST['naiss_m'] == 2){
			if($_POST['naiss_j'] == 30){
				return 'La date de naissance n\'est pas valide';
			}
			if($_POST['naiss_j'] == 29){
				if($_POST['naiss_a']%4 != 0){
					return 'La date de naissance n\'est pas valide';
				}
			}
		}
		if($_POST['naiss_a'] >= date('Y')-18){
			if($_POST['naiss_m'] >= date('m')){
				if($_POST['naiss_m'] > date('j')){
					return 'Il faut être majeur pour s\'inscrire';
				}
			}
		}
	}


?>
