<?php
/** 1ère version : liste des livres */

ob_start('ob_gzhandler'); //démarre la bufferisation, compression du tampon si le client supporte gzip

require_once '../php/bibli_generale.php';

error_reporting(E_ALL); // toutes les erreurs sont capturées (utile lors de la phase de développement)

$bd = fd_bd_connect();

$sql = 'SELECT 	liID, liTitre, liPrix, liPages, liISBN13, edNom, edWeb 
		FROM 	livres, editeurs
		WHERE liIDEditeur = edID';

$res = mysqli_query($bd, $sql) or fd_bd_erreur($bd, $sql);

fd_html_debut('BookShop | Recherche', '');

while ($t = mysqli_fetch_assoc($res)) {
	echo '<p> Livre #', $t['liID'], '</p>',
		'<ul>',
			'<li><strong>', fd_protect_sortie($t['liTitre']), '</strong></li>',
			'<li>Edit&eacute; par : <a href="http://', fd_protect_sortie($t['edWeb']), '" target="_blank">', 
			fd_protect_sortie($t['edNom']), '</a></li>',
			'<li>Prix : ', $t['liPrix'], '&euro;</li>', 
			'<li>Pages : ', $t['liPages'], '</li>',
			'<li>ISBN13 : ', fd_protect_sortie($t['liISBN13']), '</li>',
		'</ul>';
}

// libération des ressources
mysqli_free_result($res);
mysqli_close($bd);

fd_html_fin();





?>
