<?php
ob_start('ob_gzhandler'); //démarre la bufferisation, compression du tampon si le client supporte gzip

require_once '../php/bibli_generale.php';
require_once '../php/bibli_bookshop.php';

fd_html_debut('BookShop | Recherche', '../styles/bookshop.css');

fd_bookshop_enseigne_entete(true,'../');

echo '<form action=index.php methode=GET>',
	'<legend>Déjà inscrit ?</legend>',
	'<table>',
		ms_form_ligne("Email : ", ms_form_input("text", "email", "", 0)),
		ms_form_ligne("Mot de passe : ", ms_form_input("password", "pass", "", 0)),
		'<tr><td colspan=2>', ms_form_input("submit", "envoyer", "envoyer", 0), '</td></tr>',
	'</table>',
     '</form>';

fd_bookshop_pied();

fd_html_fin();

ob_end_flush();

?>
