<?php
/** 2ème version : liste des livres, résumé et des auteurs */

ob_start('ob_gzhandler'); //démarre la bufferisation, compression du tampon si le client supporte gzip

require_once '../php/bibli_generale.php';

error_reporting(E_ALL); // toutes les erreurs sont capturées (utile lors de la phase de développement)

$bd = fd_bd_connect();

$sql = 'SELECT liID, liTitre, liPrix, liPages, liResume, liISBN13, edNom, edWeb, auNom, auPrenom
		FROM livres, editeurs, auteurs, aut_livre
		WHERE liIDEditeur = edID
		AND liID = al_IDLivre
		AND auID = al_IDAuteur';

$res = mysqli_query($bd, $sql) or fd_bd_erreur($bd, $sql);

fd_html_debut('BookShop | Recherche', '');

$lastID = -1;
while ($t = mysqli_fetch_assoc($res)) {
	if ($t['liID'] != $lastID) {
		if ($lastID != -1) {
			fdl_afficher_livre($livre);	
		}
		$lastID = $t['liID'];
		$livre = array(	'id' => $t['liID'], 
						'titre' => $t['liTitre'],
						'edNom' => $t['edNom'],
						'edWeb' => $t['edWeb'],
						'resume' => $t['liResume'],
						'pages' => $t['liPages'],
						'ISBN13' => $t['liISBN13'],
						'prix' => $t['liPrix'],
						'auteurs' => array(array('prenom' => $t['auPrenom'], 'nom' => $t['auNom'])));
	}
	else {
		$livre['auteurs'][] = array('prenom' => $t['auPrenom'], 'nom' => $t['auNom']);
	}		
}
// libération des ressources
mysqli_free_result($res);
mysqli_close($bd);

if ($lastID != -1) {
	fdl_afficher_livre($livre);	
}

fd_html_fin();



/**
 *	Affichage d'un livre.
 *
 * @param	array	$t 	tableau associatif des infos sur le livre (id, auteurs(nom, prenom), titre, prix, pages, ISBN13, edWeb, edNom, resume)
 */
function fdl_afficher_livre($t) {
	echo 
		'<p style="clear: both; margin-top: 30px;">', 
			'<img src="../images/livres/', $t['id'], 
				'_mini.jpg" style="float: left; margin: 0 10px 10px 0; border: solid 1px #000; height: 100px;" alt="',
				fd_protect_sortie($t['titre']), '">',
			'<strong>', fd_protect_sortie($t['titre']), '</strong> <br>',
			'Ecrit par : ';
	$i = 0;
	foreach ($t['auteurs'] as $auteur) {
		if ($i > 0) {
			echo ', ';
		}
		$i++;
		echo fd_protect_sortie($auteur['prenom']), ' ', fd_protect_sortie($auteur['nom']);
	}
			
	echo	'<br>Editeur : <a href="http://', fd_protect_sortie($t['edWeb']), '" target="_blank">', 
				fd_protect_sortie($t['edNom']), '</a><br>',
			'Prix : ', $t['prix'], '<br>',
			'Pages : ', $t['pages'], '<br>',
			'ISBN13 : ', fd_protect_sortie($t['ISBN13']), '<br>',
			'R&eacute;sum&eacute; : <i>', fd_protect_sortie($t['resume']), '</i></p>';
		
}


?>
